# coding:utf-8
# python 3.6

from flag import flag
import re


s = "fst3Sem8Wgnobcd9+++++uv2JKpUViFGHz0QRMyjkA7NaBC14wXYxh5OP/DEqrZIl6LT"
  
assert re.match(r'^DASCTF\{[a-f0-9]+\}$',flag) != None

def encode(inputs):
    bin_str = []
    for i in inputs:
        x = str(bin(ord(i))).replace('0b', '')
        bin_str.append('{:0>8}'.format(x))
    outputs = ""
    nums = 0
    while bin_str:
        temp_list = bin_str[:3]
        if (len(temp_list) != 3):
            nums = 3 - len(temp_list)
            while len(temp_list) < 3:
                temp_list += ['0' * 8]
        temp_str = "".join(temp_list)
        temp_str_list = []
        for i in range(0, 4):
            temp_str_list.append(int(temp_str[i * 6:(i + 1) * 6], 2))
        if nums:
            temp_str_list = temp_str_list[0:4 - nums]
        for i in temp_str_list:
            outputs += s[i]
        bin_str = bin_str[3:]
    outputs += nums * '='
    return outputs
    
c = encode(flag)
print(c)
# +Se++h+mF5u0d++Oc++RbQJYbyuMb++0cYuQc+SwdmK0d+fwcYRYG+==